import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from '@/src/components/Layout';
import { mockUser, mockStudent } from '@/src/lib/mockData';
import { User } from '@/src/types';

// Pages (to be created)
import Login from '@/src/pages/Login';
import Dashboard from '@/src/pages/Dashboard';
import Courses from '@/src/pages/Courses';
import Profile from '@/src/pages/Profile';
import RetakeDashboard from '@/src/pages/RetakeDashboard';
import StudentTests from '@/src/pages/StudentTests';

export default function App() {
  const [user, setUser] = useState<User | null>(mockUser); // Default to admin for preview

  if (!user) {
    return (
      <Router>
        <Routes>
          <Route path="/login" element={<Login onLogin={setUser} />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    );
  }

  return (
    <Router>
      <Layout user={user}>
        <Routes>
          <Route path="/" element={<Dashboard user={user} />} />
          <Route path="/courses" element={<Courses user={user} />} />
          <Route path="/manage-courses" element={<Courses user={user} />} />
          <Route path="/profile" element={<Profile user={user} />} />
          <Route path="/retake" element={<RetakeDashboard user={user} />} />
          <Route path="/student-tests" element={<StudentTests user={user} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
}
