export type UserRole = 'STUDENT' | 'TEACHER' | 'ADMIN' | 'RET_SUPERVISOR' | 'RET_ACCOUNTANT';

export interface User {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  role: UserRole;
  avatar_url?: string;
  phone?: string;
}

export interface Course {
  id: number;
  title: string;
  description: string;
  teacher: User;
  is_active: boolean;
  deadline?: string;
  image_url?: string;
  sections_count: number;
  students_count: number;
}

export interface Section {
  id: number;
  course_id: number;
  name: string;
  description?: string;
  is_published: boolean;
  order: number;
}

export interface Resource {
  id: number;
  section_id: number;
  title: string;
  resource_type: 'file' | 'link' | 'video' | 'text';
  url?: string;
  content?: string;
  file_url?: string;
}

export interface Test {
  id: number;
  course_id: number;
  section_id?: number;
  name: string;
  description?: string;
  start_datetime?: string;
  end_datetime?: string;
  duration_minutes: number;
  max_score: number;
  attempts: number;
  proctoring_enabled: boolean;
  face_id_required: boolean;
}

export interface RetakeApplication {
  id: number;
  student_id: number;
  cycle_id: number;
  status: 'draft' | 'in_review' | 'partially_approved' | 'approved' | 'completed' | 'rejected';
  declared_amount?: number;
  accountant_amount?: number;
  created_at: string;
  updated_at: string;
}
